export interface Employee {
  employeeID: string;
  firstName: string;
  lastName: string;
  company: string;
  designation: string;
  email: string;
}
